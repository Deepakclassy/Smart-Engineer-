function round(num){
    return Math.round(num*100)/100;
}
const num=40.80;
const result=round(num);
console.log(result);
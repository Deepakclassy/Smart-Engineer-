alpha="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const vawr=alpha.substring(0,4);
console.log(vawr);
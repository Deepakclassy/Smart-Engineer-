let x = 10,y=20
let sum  = x+y
let big=x>y?x:y
console.log(x+"+"+y+"=" +sum)
console.log("large="+big)
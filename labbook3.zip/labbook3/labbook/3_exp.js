let x=11,mesg=""
if(x%2==0)
mesg="Even";
else
mesg="odd";
console.log(x+"is"+mesg)
let i=3,mesg=[]
switch(i)
{
    case 1:
    mesg="One"
    break;
    case 2:mesg="Two"
    break;
    default:mesg="Default";
}
console.log(mesg);
var i,j;
for(i=19;1>0;i--)
{
    for(j=1;j<=i;j++)
    console.log(i+" ");
console.log();
}
var num =123
var count=0
do{
  count++;
  num/=10;
} while(num>1);
console.log(count);